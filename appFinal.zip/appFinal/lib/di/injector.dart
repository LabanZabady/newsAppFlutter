import 'package:dio/dio.dart';
import '../features/news/data/datasources/news_api_service.dart';

final sl = <Type, dynamic>{};

Future<void> init() async {
  const String baseUrl = 'https://newsapi.org/v2';
  const String apiKey = 'c5048003527a415a8d217af3a3546db5'; // put your actual key here

  // Store singletons manually (no GetIt)
  sl[Dio] = Dio();
  sl[NewsApiService] = NewsApiService(
    sl[Dio] as Dio,
    baseUrl: baseUrl,
    apiKey: apiKey,
  );
}

T getIt<T>() => sl[T] as T;