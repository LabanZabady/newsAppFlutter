import 'package:flutter/material.dart';
import 'di/injector.dart';
import 'app.dart';
import 'features/news/data/datasources/news_api_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await init(); // initialize dependencies

  // Optional: quick test fetch to see if API key works
  final newsService = getIt<NewsApiService>();
  final headlines = await newsService.getTopHeadlines();
  print(headlines); // check console for results

  runApp(const MyApp());
}