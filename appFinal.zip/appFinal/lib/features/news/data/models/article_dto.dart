class ArticleDto {
  final String? author;
  final String title;
  final String? description;
  final String url;
  final String? urlToImage;
  final String? content;
  final String? publishedAt; // ISO8601

  ArticleDto({
    required this.title,
    required this.url,
    this.author,
    this.description,
    this.urlToImage,
    this.content,
    this.publishedAt,
  });

  factory ArticleDto.fromJson(Map<String, dynamic> json) {
    return ArticleDto(
      author: json['author'] as String?,
      title: (json['title'] ?? '') as String,
      description: json['description'] as String?,
      url: (json['url'] ?? '') as String,
      urlToImage: json['urlToImage'] as String?,
      content: json['content'] as String?,
      publishedAt: json['publishedAt'] as String?,
    );
  }
}