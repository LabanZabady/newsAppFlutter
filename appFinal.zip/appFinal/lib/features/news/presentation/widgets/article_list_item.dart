import 'package:flutter/material.dart';
import '../../domain/entities/article.dart';
import 'package:intl/intl.dart';

class ArticleListItem extends StatelessWidget {
  final Article article;
  final VoidCallback onTap;
  const ArticleListItem({super.key, required this.article, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final date = article.publishedAt != null ? DateFormat.yMMMd().format(article.publishedAt!) : '';
    return ListTile(
      leading: _ImageThumb(url: article.imageUrl),
      title: Text(article.title, maxLines: 2, overflow: TextOverflow.ellipsis),
      subtitle: Text(date),
      onTap: onTap,
    );
  }
}

class _ImageThumb extends StatelessWidget {
  final String? url;
  const _ImageThumb({required this.url});
  @override
  Widget build(BuildContext context) {
    if (url == null) {
      return const SizedBox(width: 56, height: 56, child: Icon(Icons.image_not_supported));
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(6),
      child: Image.network(
        url!,
        width: 56, height: 56, fit: BoxFit.cover,
        loadingBuilder: (c, w, p) => p == null ? w : const SizedBox(width: 56, height: 56, child: Center(child: CircularProgressIndicator(strokeWidth: 2))),
        errorBuilder: (_, __, ___) => const SizedBox(width: 56, height: 56, child: Icon(Icons.broken_image)),
      ),
    );
  }
}