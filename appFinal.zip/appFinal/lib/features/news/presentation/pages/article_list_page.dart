import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/article_list_bloc.dart';
import '../bloc/article_list_state.dart';
import '../bloc/article_list_event.dart';
import '../widgets/article_list_item.dart';
import 'article_detail_page.dart';

class ArticleListPage extends StatelessWidget {
  const ArticleListPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Top Headlines')),
      body: BlocBuilder<ArticleListBloc, ArticleListState>(
        builder: (context, state) {
          if (state is ArticleListLoading) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is ArticleListLoaded) {
            if (state.articles.isEmpty) {
              return const Center(child: Text('No articles found.'));
            }
            return RefreshIndicator(
              onRefresh: () async => context.read<ArticleListBloc>().add(const LoadArticles()),
              child: ListView.separated(
                itemCount: state.articles.length,
                separatorBuilder: (_, __) => const Divider(height: 0),
                itemBuilder: (context, index) {
                  final a = state.articles[index];
                  return ArticleListItem(
                    article: a,
                    onTap: () {
                      Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => ArticleDetailPage(article: a),
                      ));
                    },
                  );
                },
              ),
            );
          } else if (state is ArticleListError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('Oops: ${state.message}', textAlign: TextAlign.center),
                    const SizedBox(height: 12),
                    FilledButton(
                      onPressed: () => context.read<ArticleListBloc>().add(const LoadArticles()),
                      child: const Text('Retry'),
                    ),
                  ],
                ),
              ),
            );
          }
          context.read<ArticleListBloc>().add(const LoadArticles());
          return const SizedBox.shrink();
        },
      ),
    );
  }
}