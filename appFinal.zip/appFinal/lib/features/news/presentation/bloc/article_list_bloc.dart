import 'package:flutter_bloc/flutter_bloc.dart';
import 'article_list_event.dart';
import 'article_list_state.dart';
import '../../domain/usecases/get_top_headlines.dart';

class ArticleListBloc extends Bloc<ArticleListEvent, ArticleListState> {
  final GetTopHeadlines _getTopHeadlines;

  ArticleListBloc(this._getTopHeadlines) : super(ArticleListInitial()) {
    on<LoadArticles>((event, emit) async {
      emit(ArticleListLoading());
      try {
        final articles = await _getTopHeadlines(
          GetTopHeadlinesParams(country: event.country),
        );
        emit(ArticleListLoaded(articles));
      } catch (e) {
        emit(ArticleListError(e.toString()));
      }
    });
  }
}