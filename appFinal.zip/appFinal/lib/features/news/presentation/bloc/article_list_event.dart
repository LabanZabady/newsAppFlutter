import 'package:equatable/equatable.dart';

abstract class ArticleListEvent extends Equatable {
  const ArticleListEvent();
  @override
  List<Object?> get props => [];
}

class LoadArticles extends ArticleListEvent {
  final String country;
  const LoadArticles({this.country = 'us'});
  @override
  List<Object?> get props => [country];
}