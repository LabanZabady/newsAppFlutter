import 'package:equatable/equatable.dart';
import '../../domain/entities/article.dart';

abstract class ArticleListState extends Equatable {
  const ArticleListState();
  @override
  List<Object?> get props => [];
}

class ArticleListInitial extends ArticleListState {}

class ArticleListLoading extends ArticleListState {}

class ArticleListLoaded extends ArticleListState {
  final List<Article> articles;
  const ArticleListLoaded(this.articles);
  @override
  List<Object?> get props => [articles];
}

class ArticleListError extends ArticleListState {
  final String message;
  const ArticleListError(this.message);
  @override
  List<Object?> get props => [message];
}