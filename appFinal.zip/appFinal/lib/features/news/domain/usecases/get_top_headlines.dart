import 'package:untitled3/core/usecase.dart';
import '../entities/article.dart';
import '../repositories/article_repository.dart';

class GetTopHeadlines implements UseCase<List<Article>, GetTopHeadlinesParams> {
  final ArticleRepository repository;
  GetTopHeadlines(this.repository);

  @override
  Future<List<Article>> call(GetTopHeadlinesParams params) {
    return repository.getTopHeadlines(country: params.country, page: params.page);
  }
}

class GetTopHeadlinesParams {
  final String country;
  final int page;
  GetTopHeadlinesParams({this.country = 'us', this.page = 1});
}