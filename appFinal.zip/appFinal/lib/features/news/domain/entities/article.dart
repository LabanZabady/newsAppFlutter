import 'package:equatable/equatable.dart';

class Article extends Equatable {
  final String id;            // synthesized from url or UUID
  final String title;
  final String? imageUrl;
  final DateTime? publishedAt;
  final String? content;
  final String? description;
  final String url;

  const Article({
    required this.id,
    required this.title,
    this.imageUrl,
    this.publishedAt,
    this.content,
    this.description,
    required this.url,
  });

  @override
  List<Object?> get props => [id, title, imageUrl, publishedAt, content, description, url];
}