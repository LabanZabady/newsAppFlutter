import 'package:flutter/material.dart';
import '../di/injector.dart';
import 'features/news/data/datasources/news_api_service.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'News App',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const NewsPage(),
    );
  }
}

class NewsPage extends StatefulWidget {
  const NewsPage({super.key});

  @override
  State<NewsPage> createState() => _NewsPageState();
}

class _NewsPageState extends State<NewsPage> {
  List articles = [];
  bool loading = true;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    _loadNews();
  }

  Future<void> _loadNews() async {
    try {
      final service = getIt<NewsApiService>();
      final data = await service.getTopHeadlines();
      setState(() {
        articles = data['articles'] ?? [];
        loading = false;
      });
    } catch (e) {
      setState(() {
        errorMessage = e.toString();
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (errorMessage != null) {
      return Scaffold(
        appBar: AppBar(title: const Text("News")),
        body: Center(child: Text("Error: $errorMessage")),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text("Top Headlines")),
      body: ListView.builder(
        itemCount: articles.length,
        itemBuilder: (context, index) {
          final article = articles[index];
          return ListTile(
            leading: article['urlToImage'] != null
                ? Image.network(article['urlToImage'], width: 60, fit: BoxFit.cover)
                : const Icon(Icons.image),
            title: Text(article['title'] ?? 'No title'),
            subtitle: Text(article['publishedAt'] ?? ''),
          );
        },
      ),
    );
  }
}